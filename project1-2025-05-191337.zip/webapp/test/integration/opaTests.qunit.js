/* global QUnit */

sap.ui.require(["com/acn/training/project1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
